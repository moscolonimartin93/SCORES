// ── SCORES DATABASE ──────────────────────────────────────────────────────────
const SCORES = {

  tobillo: [
    {
      id: 'aofas', nombre: 'AOFAS Ankle-Hindfoot', max: 100,
      interp: s => s >= 90 ? 'Excelente' : s >= 75 ? 'Bueno' : s >= 50 ? 'Regular' : 'Malo',
      secciones: [
        { t: 'Dolor', qs: [
          { id: 'd1', txt: 'Dolor en tobillo / pie', ops: [
            { t: 'Ninguno', v: 40 },
            { t: 'Leve, ocasional', v: 30 },
            { t: 'Moderado, diario', v: 20 },
            { t: 'Severo, casi siempre', v: 0 }
          ]}
        ]},
        { t: 'Función', qs: [
          { id: 'f1', txt: 'Limitación de actividad y soporte', ops: [
            { t: 'Sin limitación, sin apoyo', v: 10 },
            { t: 'Sin limitación diaria, limitación recreativa, sin apoyo', v: 7 },
            { t: 'Limitación diaria y recreativa, con bastón', v: 4 },
            { t: 'Limitación severa, andador / muletas / silla de ruedas', v: 0 }
          ]},
          { id: 'f2', txt: 'Distancia máxima caminada', ops: [
            { t: 'Más de 6 cuadras', v: 5 },
            { t: '4 a 6 cuadras', v: 4 },
            { t: '1 a 3 cuadras', v: 2 },
            { t: 'Menos de 1 cuadra', v: 0 }
          ]},
          { id: 'f3', txt: 'Superficie de caminata', ops: [
            { t: 'Sin dificultad en cualquier superficie', v: 5 },
            { t: 'Dificultad en terreno irregular o escaleras', v: 3 },
            { t: 'Dificultad severa en terreno irregular', v: 0 }
          ]},
          { id: 'f4', txt: 'Anomalía de la marcha', ops: [
            { t: 'Ninguna o leve', v: 8 },
            { t: 'Evidente', v: 4 },
            { t: 'Marcada', v: 0 }
          ]},
          { id: 'f5', txt: 'Movilidad sagital (flexión + extensión)', ops: [
            { t: 'Normal o leve restricción (≥30°)', v: 8 },
            { t: 'Restricción moderada (15–29°)', v: 4 },
            { t: 'Restricción severa (<15°)', v: 0 }
          ]},
          { id: 'f6', txt: 'Estabilidad articular', ops: [
            { t: 'Estable', v: 8 },
            { t: 'Inestable', v: 0 }
          ]}
        ]},
        { t: 'Alineación', qs: [
          { id: 'a1', txt: 'Alineación del pie', ops: [
            { t: 'Buena – pie plantigrado, alineación normal', v: 10 },
            { t: 'Regular – plantigrado, leve mal alineación sin síntomas', v: 5 },
            { t: 'Mala – no plantigrado, alineación severa con síntomas', v: 0 }
          ]}
        ]}
      ]
    },
    {
      id: 'fadi', nombre: 'FADI – Foot & Ankle Disability Index', max: 104,
      interp: s => { const p = Math.round(s / 104 * 100); return p >= 90 ? 'Mínima discapacidad' : p >= 70 ? 'Discapacidad leve' : p >= 50 ? 'Discapacidad moderada' : 'Discapacidad severa'; },
      secciones: [
        { t: 'Actividades (0 = sin dificultad · 4 = incapaz)', qs: [
          { id: 'fa1', txt: 'Pararse', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa2', txt: 'Caminar sobre superficie plana', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa3', txt: 'Subir escaleras', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa4', txt: 'Bajar escaleras', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa5', txt: 'Pararse en puntas de pie', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa6', txt: 'Caminar en superficie irregular', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa7', txt: 'Caminar 2 cuadras', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa8', txt: 'Caminar más de 8 cuadras', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa9', txt: 'Entrar / salir del auto', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa10', txt: 'Cuidados personales (bañarse, vestirse)', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa11', txt: 'Tareas domésticas livianas', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa12', txt: 'Actividades recreativas livianas', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa13', txt: 'Correr', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa14', txt: 'Agacharse / arrodillarse', ops: [{t:'Sin dificultad',v:4},{t:'Dificultad leve',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'fa15', txt: 'Dolor al final del día', ops: [{t:'Ninguno',v:4},{t:'Leve',v:3},{t:'Moderado',v:2},{t:'Severo',v:1},{t:'Insoportable',v:0}] }
        ]}
      ]
    }
  ],

  rodilla: [
    {
      id: 'lysholm', nombre: 'Tegner-Lysholm Knee Scale', max: 100,
      interp: s => s >= 95 ? 'Excelente' : s >= 84 ? 'Bueno' : s >= 65 ? 'Regular' : 'Malo',
      secciones: [{ t: 'Evaluación funcional', qs: [
        { id: 'r1', txt: 'Cojera', ops: [{t:'Ninguna',v:5},{t:'Leve o periódica',v:3},{t:'Severa y constante',v:0}] },
        { id: 'r2', txt: 'Apoyo al caminar', ops: [{t:'Soporte completo sin dolor',v:5},{t:'Soporte completo con dolor',v:3},{t:'Sin carga de peso',v:0}] },
        { id: 'r3', txt: 'Bloqueo articular', ops: [{t:'Sin bloqueo ni sensación de bloqueo',v:15},{t:'Sensación de bloqueo sin bloqueo real',v:10},{t:'Bloqueo ocasional',v:6},{t:'Bloqueo frecuente',v:2},{t:'Articulación bloqueada al examen',v:0}] },
        { id: 'r4', txt: 'Inestabilidad', ops: [{t:'Sin cedimiento',v:25},{t:'Raramente en esfuerzo extremo',v:20},{t:'Frecuentemente en esfuerzo extremo',v:15},{t:'Ocasionalmente en actividades cotidianas',v:10},{t:'Frecuentemente en actividades cotidianas',v:5},{t:'Con cada paso',v:0}] },
        { id: 'r5', txt: 'Dolor', ops: [{t:'Ninguno',v:25},{t:'Inconstante, leve al ejercicio intenso',v:20},{t:'Marcado al ejercicio intenso',v:15},{t:'Marcado al caminar >2 km',v:10},{t:'Marcado al caminar <2 km',v:5},{t:'Constante',v:0}] },
        { id: 'r6', txt: 'Edema articular', ops: [{t:'Ninguno',v:10},{t:'Con ejercicio intenso',v:6},{t:'Con ejercicio ordinario',v:2},{t:'Constante',v:0}] },
        { id: 'r7', txt: 'Subir escaleras', ops: [{t:'Sin dificultad',v:10},{t:'Leve dificultad',v:6},{t:'Un escalón a la vez',v:2},{t:'Imposible',v:0}] },
        { id: 'r8', txt: 'Agacharse / cuclillas', ops: [{t:'Sin dificultad',v:5},{t:'Leve dificultad',v:4},{t:'Hasta 90°',v:2},{t:'Imposible',v:0}] }
      ]}]
    },
    {
      id: 'kss', nombre: 'Knee Society Score (KSS)', max: 100,
      interp: s => s >= 80 ? 'Excelente' : s >= 70 ? 'Bueno' : s >= 60 ? 'Regular' : 'Malo',
      secciones: [
        { t: 'Dolor (50 pts)', qs: [{ id: 'k1', txt: 'Nivel de dolor en rodilla', ops: [{t:'Ninguno',v:50},{t:'Leve o esporádico',v:45},{t:'Solo al subir escaleras',v:40},{t:'Al caminar y escaleras',v:30},{t:'Moderado, ocasional',v:20},{t:'Moderado, continuo',v:10},{t:'Severo',v:0}] }]},
        { t: 'Estabilidad (25 pts)', qs: [
          { id: 'k2', txt: 'Estabilidad anteroposterior', ops: [{t:'<5 mm',v:10},{t:'6–10 mm',v:5},{t:'>10 mm',v:0}] },
          { id: 'k3', txt: 'Estabilidad mediolateral', ops: [{t:'<5°',v:15},{t:'6–9°',v:10},{t:'10–14°',v:5},{t:'>14°',v:0}] }
        ]},
        { t: 'Rango de movimiento (25 pts)', qs: [{ id: 'k4', txt: 'Arco de movimiento', ops: [{t:'≥125°',v:25},{t:'110–124°',v:22},{t:'95–109°',v:19},{t:'80–94°',v:16},{t:'<80°',v:10}] }]}
      ]
    },
    {
      id: 'koos', nombre: 'KOOS – Knee Injury & OA Outcome', max: 100,
      interp: s => s >= 80 ? 'Excelente' : s >= 60 ? 'Bueno' : s >= 40 ? 'Regular' : 'Malo',
      secciones: [
        { t: 'Síntomas', qs: [
          { id: 'ko1', txt: 'Hinchazón de rodilla', ops: [{t:'Nunca',v:4},{t:'Raramente',v:3},{t:'Algunas veces',v:2},{t:'Con frecuencia',v:1},{t:'Siempre',v:0}] },
          { id: 'ko2', txt: 'Crujidos u otros ruidos al mover la rodilla', ops: [{t:'Nunca',v:4},{t:'Raramente',v:3},{t:'Algunas veces',v:2},{t:'Con frecuencia',v:1},{t:'Siempre',v:0}] },
          { id: 'ko3', txt: 'Rigidez al despertar por la mañana', ops: [{t:'Ninguna',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Extrema',v:0}] }
        ]},
        { t: 'Dolor (últimos 7 días)', qs: [
          { id: 'ko4', txt: 'Dolor al girar / pivotar sobre la rodilla', ops: [{t:'Nunca',v:4},{t:'Raramente',v:3},{t:'Algunas veces',v:2},{t:'Con frecuencia',v:1},{t:'Siempre',v:0}] },
          { id: 'ko5', txt: 'Dolor al extender completamente la rodilla', ops: [{t:'Nunca',v:4},{t:'Raramente',v:3},{t:'Algunas veces',v:2},{t:'Con frecuencia',v:1},{t:'Siempre',v:0}] },
          { id: 'ko6', txt: 'Dolor al subir o bajar escaleras', ops: [{t:'Nunca',v:4},{t:'Raramente',v:3},{t:'Algunas veces',v:2},{t:'Con frecuencia',v:1},{t:'Siempre',v:0}] }
        ]},
        { t: 'Actividad física', qs: [
          { id: 'ko7', txt: 'Agacharse (cuclillas)', ops: [{t:'Sin dificultad',v:4},{t:'Poca dificultad',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad extrema',v:1},{t:'Imposible',v:0}] },
          { id: 'ko8', txt: 'Arrodillarse', ops: [{t:'Sin dificultad',v:4},{t:'Poca dificultad',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad extrema',v:1},{t:'Imposible',v:0}] },
          { id: 'ko9', txt: 'Levantarse de una silla', ops: [{t:'Sin dificultad',v:4},{t:'Poca dificultad',v:3},{t:'Dificultad moderada',v:2},{t:'Dificultad extrema',v:1},{t:'Imposible',v:0}] }
        ]}
      ]
    }
  ],

  cadera: [
    {
      id: 'harris', nombre: 'Harris Hip Score', max: 100,
      interp: s => s >= 90 ? 'Excelente' : s >= 80 ? 'Bueno' : s >= 70 ? 'Regular' : 'Malo',
      secciones: [
        { t: 'Dolor (44 pts)', qs: [{ id: 'h1', txt: 'Nivel de dolor en cadera', ops: [
          {t:'Ninguno / ignora el dolor',v:44},
          {t:'Leve, ocasional, sin compromiso de actividad',v:40},
          {t:'Leve, actividad normal, analgésicos ocasionales',v:30},
          {t:'Moderado, tolerable, actividad limitada',v:20},
          {t:'Marcado, actividad muy limitada',v:10},
          {t:'Discapacitante, en cama',v:0}
        ]}]},
        { t: 'Función – marcha (33 pts)', qs: [
          { id: 'h2', txt: 'Cojera', ops: [{t:'Ninguna',v:11},{t:'Leve',v:8},{t:'Moderada',v:5},{t:'Severa',v:0}] },
          { id: 'h3', txt: 'Soporte para caminar', ops: [{t:'Ninguno',v:11},{t:'Bastón en largas caminatas',v:7},{t:'Bastón la mayor parte del tiempo',v:5},{t:'Una muleta',v:3},{t:'Dos bastones',v:2},{t:'Dos muletas o imposible',v:0}] },
          { id: 'h4', txt: 'Distancia caminada', ops: [{t:'Sin límite',v:11},{t:'6 cuadras',v:8},{t:'2–3 cuadras',v:5},{t:'Solo en interiores',v:2},{t:'Cama y silla',v:0}] }
        ]},
        { t: 'Función – actividades (14 pts)', qs: [
          { id: 'h5', txt: 'Escaleras', ops: [{t:'Normalmente sin apoyo',v:4},{t:'Normalmente con apoyo',v:2},{t:'De a uno con apoyo',v:1},{t:'Imposible',v:0}] },
          { id: 'h6', txt: 'Calzarse', ops: [{t:'Con facilidad',v:4},{t:'Con dificultad',v:2},{t:'Imposible',v:0}] },
          { id: 'h7', txt: 'Sentarse en silla', ops: [{t:'Cómodo en cualquier silla 1 hora',v:5},{t:'Alto, cómodo media hora',v:3},{t:'Incómodo',v:0}] },
          { id: 'h8', txt: 'Transporte público', ops: [{t:'Puede usar',v:1},{t:'No puede usar',v:0}] }
        ]},
        { t: 'Deformidad y movilidad (9 pts)', qs: [
          { id: 'h9', txt: 'Deformidad', ops: [{t:'Sin deformidad en ningún parámetro',v:4},{t:'Una deformidad leve',v:2},{t:'Dos o más deformidades',v:0}] },
          { id: 'h10', txt: 'Rango de movimiento combinado', ops: [{t:'>210°',v:5},{t:'160–210°',v:4},{t:'100–159°',v:3},{t:'<100°',v:0}] }
        ]}
      ]
    }
  ],

  hombro: [
    {
      id: 'constant', nombre: 'Constant Shoulder Score', max: 100,
      interp: s => s >= 91 ? 'Excelente' : s >= 71 ? 'Bueno' : s >= 51 ? 'Moderado' : 'Pobre',
      secciones: [
        { t: 'Dolor (15 pts)', qs: [{ id: 'c1', txt: 'Dolor en hombro', ops: [{t:'Sin dolor',v:15},{t:'Leve',v:10},{t:'Moderado',v:5},{t:'Severo',v:0}] }]},
        { t: 'Actividades de la vida diaria (20 pts)', qs: [
          { id: 'c2', txt: 'Nivel de actividad laboral y recreativa', ops: [{t:'Trabajo full / deporte completo / sueño no perturbado',v:10},{t:'Trabajo moderado / deporte moderado',v:8},{t:'Trabajo liviano / poco deporte',v:5},{t:'Sin trabajo ni deporte',v:0}] },
          { id: 'c3', txt: 'Posición de la mano en trabajo', ops: [{t:'Hasta cintura',v:2},{t:'Hasta xifoides',v:4},{t:'Hasta cuello',v:6},{t:'Hasta cabeza',v:8},{t:'Por encima de la cabeza',v:10}] }
        ]},
        { t: 'Movilidad (40 pts)', qs: [
          { id: 'c4', txt: 'Flexión anterior', ops: [{t:'0–30°',v:0},{t:'31–60°',v:2},{t:'61–90°',v:4},{t:'91–120°',v:6},{t:'121–150°',v:8},{t:'151–180°',v:10}] },
          { id: 'c5', txt: 'Abducción', ops: [{t:'0–30°',v:0},{t:'31–60°',v:2},{t:'61–90°',v:4},{t:'91–120°',v:6},{t:'121–150°',v:8},{t:'151–180°',v:10}] },
          { id: 'c6', txt: 'Rotación externa', ops: [{t:'Mano detrás de cabeza, codo adelante',v:2},{t:'Mano detrás de cabeza, codo atrás',v:4},{t:'Mano encima de cabeza, codo adelante',v:6},{t:'Mano encima de cabeza, codo atrás',v:8},{t:'Elevación completa',v:10}] },
          { id: 'c7', txt: 'Rotación interna', ops: [{t:'Cara lateral del muslo',v:0},{t:'Nalga',v:2},{t:'Articulación lumbosacra',v:4},{t:'Cintura (L3)',v:6},{t:'T12',v:8},{t:'Escápula o más alto',v:10}] }
        ]},
        { t: 'Fuerza (25 pts)', qs: [{ id: 'c8', txt: 'Fuerza en abducción', ops: [{t:'0 libras',v:0},{t:'~5 libras (2.3 kg)',v:5},{t:'~10 libras (4.5 kg)',v:10},{t:'~15 libras (6.8 kg)',v:15},{t:'~20 libras (9 kg)',v:20},{t:'25+ libras (≥11 kg)',v:25}] }]}
      ]
    },
    {
      id: 'ases', nombre: 'ASES – American Shoulder & Elbow', max: 100,
      interp: s => s >= 80 ? 'Excelente' : s >= 60 ? 'Bueno' : s >= 40 ? 'Regular' : 'Malo',
      secciones: [
        { t: 'Dolor (VAS 0–10)', qs: [{ id: 'as1', txt: 'Nivel de dolor (0 = sin dolor · 10 = máximo)', ops: [{t:'0 – Sin dolor',v:10},{t:'1–2',v:8},{t:'3–4',v:6},{t:'5–6',v:4},{t:'7–8',v:2},{t:'9–10 – Dolor máximo',v:0}] }]},
        { t: 'Función (10 actividades)', qs: [
          { id: 'as2', txt: 'Ponerse el abrigo', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as3', txt: 'Dormir del lado afectado', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as4', txt: 'Lavarse la espalda', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as5', txt: 'Higiene personal', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as6', txt: 'Peinarse', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as7', txt: 'Alcanzar estante sobre los hombros', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as8', txt: 'Levantar 4.5 kg sobre los hombros', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as9', txt: 'Lanzar pelota por arriba', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as10', txt: 'Trabajo habitual', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] },
          { id: 'as11', txt: 'Actividad deportiva habitual', ops: [{t:'Sin dificultad',v:4},{t:'Leve',v:3},{t:'Moderada',v:2},{t:'Severa',v:1},{t:'Incapaz',v:0}] }
        ]}
      ]
    }
  ],

  femur: [
    {
      id: 'sf12', nombre: 'SF-12 Función Postoperatoria (Fémur)', max: 100,
      interp: s => s >= 75 ? 'Buena función' : s >= 50 ? 'Función moderada' : s >= 25 ? 'Función limitada' : 'Muy limitada',
      secciones: [
        { t: 'Función física', qs: [
          { id: 'sf1', txt: '¿Le limita para actividades moderadas (mover muebles, aspirar)?', ops: [{t:'No me limita nada',v:4},{t:'Me limita un poco',v:2},{t:'Me limita mucho',v:0}] },
          { id: 'sf2', txt: '¿Le limita subir varios pisos por escalera?', ops: [{t:'No me limita nada',v:4},{t:'Me limita un poco',v:2},{t:'Me limita mucho',v:0}] }
        ]},
        { t: 'Rol físico', qs: [
          { id: 'sf3', txt: '¿Hizo menos de lo que quería por problemas físicos?', ops: [{t:'No',v:4},{t:'Sí',v:0}] },
          { id: 'sf4', txt: '¿Tuvo que dejar tareas por problemas físicos?', ops: [{t:'No',v:4},{t:'Sí',v:0}] }
        ]},
        { t: 'Dolor', qs: [{ id: 'sf5', txt: 'Dolor físico en las últimas 4 semanas', ops: [{t:'Ninguno',v:12},{t:'Muy poco',v:10},{t:'Un poco',v:8},{t:'Moderado',v:5},{t:'Mucho',v:2},{t:'Muchísimo',v:0}] }]},
        { t: 'Función social', qs: [{ id: 'sf6', txt: '¿Problemas físicos limitaron actividades sociales?', ops: [{t:'Nunca',v:12},{t:'Casi nunca',v:9},{t:'Algunas veces',v:6},{t:'Casi siempre',v:3},{t:'Siempre',v:0}] }]},
        { t: 'Vitalidad', qs: [{ id: 'sf7', txt: '¿Cuánto tiempo tuvo energía? (últimas 4 semanas)', ops: [{t:'Siempre',v:12},{t:'Casi siempre',v:9},{t:'Algunas veces',v:6},{t:'Casi nunca',v:3},{t:'Nunca',v:0}] }]},
        { t: 'Salud mental', qs: [
          { id: 'sf8', txt: '¿Cuánto tiempo se sintió tranquilo y sereno?', ops: [{t:'Siempre',v:12},{t:'Casi siempre',v:9},{t:'Algunas veces',v:6},{t:'Casi nunca',v:3},{t:'Nunca',v:0}] },
          { id: 'sf9', txt: '¿Cuánto tiempo se sintió desanimado o triste?', ops: [{t:'Nunca',v:12},{t:'Casi nunca',v:9},{t:'Algunas veces',v:6},{t:'Casi siempre',v:3},{t:'Siempre',v:0}] }
        ]}
      ]
    }
  ],

  humero: [
    {
      id: 'mayo', nombre: 'Mayo Elbow Performance Score', max: 100,
      interp: s => s >= 90 ? 'Excelente' : s >= 75 ? 'Bueno' : s >= 60 ? 'Regular' : 'Malo',
      secciones: [
        { t: 'Dolor (45 pts)', qs: [{ id: 'me1', txt: 'Dolor en codo', ops: [{t:'Ninguno',v:45},{t:'Leve',v:30},{t:'Moderado',v:15},{t:'Severo',v:0}] }]},
        { t: 'Movilidad (20 pts)', qs: [{ id: 'me2', txt: 'Arco de flexo-extensión', ops: [{t:'>100°',v:20},{t:'50–100°',v:15},{t:'<50°',v:5}] }]},
        { t: 'Estabilidad (10 pts)', qs: [{ id: 'me3', txt: 'Estabilidad articular', ops: [{t:'Estable',v:10},{t:'Moderadamente inestable',v:5},{t:'Grossamente inestable',v:0}] }]},
        { t: 'Función (25 pts)', qs: [
          { id: 'me4', txt: 'Puede peinarse', ops: [{t:'Sí',v:5},{t:'No',v:0}] },
          { id: 'me5', txt: 'Puede comer independientemente', ops: [{t:'Sí',v:5},{t:'No',v:0}] },
          { id: 'me6', txt: 'Higiene personal', ops: [{t:'Sí',v:5},{t:'No',v:0}] },
          { id: 'me7', txt: 'Puede ponerse la camisa', ops: [{t:'Sí',v:5},{t:'No',v:0}] },
          { id: 'me8', txt: 'Puede ponerse los zapatos', ops: [{t:'Sí',v:5},{t:'No',v:0}] }
        ]}
      ]
    },
    {
      id: 'qdash', nombre: 'Quick-DASH (Miembro Superior)', max: 100,
      interp: s => s <= 20 ? 'Mínima discapacidad' : s <= 40 ? 'Discapacidad leve' : s <= 60 ? 'Discapacidad moderada' : 'Discapacidad severa',
      secciones: [{ t: '11 ítems (1 = sin dificultad · 5 = incapaz)', qs: [
        { id: 'qd1', txt: 'Abrir un frasco apretado', ops: [{t:'Sin dificultad',v:1},{t:'Poca dificultad',v:2},{t:'Dificultad moderada',v:3},{t:'Mucha dificultad',v:4},{t:'Incapaz',v:5}] },
        { id: 'qd2', txt: 'Tareas domésticas pesadas (lavar pisos, mover muebles)', ops: [{t:'Sin dificultad',v:1},{t:'Poca dificultad',v:2},{t:'Dificultad moderada',v:3},{t:'Mucha dificultad',v:4},{t:'Incapaz',v:5}] },
        { id: 'qd3', txt: 'Cargar bolsa de compras o maletín', ops: [{t:'Sin dificultad',v:1},{t:'Poca dificultad',v:2},{t:'Dificultad moderada',v:3},{t:'Mucha dificultad',v:4},{t:'Incapaz',v:5}] },
        { id: 'qd4', txt: 'Lavarse la espalda', ops: [{t:'Sin dificultad',v:1},{t:'Poca dificultad',v:2},{t:'Dificultad moderada',v:3},{t:'Mucha dificultad',v:4},{t:'Incapaz',v:5}] },
        { id: 'qd5', txt: 'Usar cuchillo para cortar alimentos', ops: [{t:'Sin dificultad',v:1},{t:'Poca dificultad',v:2},{t:'Dificultad moderada',v:3},{t:'Mucha dificultad',v:4},{t:'Incapaz',v:5}] },
        { id: 'qd6', txt: 'Actividades recreativas con fuerza (tenis, martillar)', ops: [{t:'Sin dificultad',v:1},{t:'Poca dificultad',v:2},{t:'Dificultad moderada',v:3},{t:'Mucha dificultad',v:4},{t:'Incapaz',v:5}] },
        { id: 'qd7', txt: 'Actividades con carga en brazo/hombro/mano', ops: [{t:'Sin dificultad',v:1},{t:'Poca dificultad',v:2},{t:'Dificultad moderada',v:3},{t:'Mucha dificultad',v:4},{t:'Incapaz',v:5}] },
        { id: 'qd8', txt: 'Limitación general de movilidad del brazo', ops: [{t:'Sin limitación',v:1},{t:'Limitación leve',v:2},{t:'Limitación moderada',v:3},{t:'Limitación severa',v:4},{t:'Sin posibilidad',v:5}] },
        { id: 'qd9', txt: 'Dolor en brazo/hombro/mano (últimos 7 días)', ops: [{t:'Ninguno',v:1},{t:'Leve',v:2},{t:'Moderado',v:3},{t:'Severo',v:4},{t:'Extremo',v:5}] },
        { id: 'qd10', txt: 'Hormigueo en brazo/hombro/mano', ops: [{t:'Ninguno',v:1},{t:'Leve',v:2},{t:'Moderado',v:3},{t:'Severo',v:4},{t:'Extremo',v:5}] },
        { id: 'qd11', txt: 'Dificultad para dormir por dolor en brazo/hombro/mano', ops: [{t:'Sin dificultad',v:1},{t:'Poca dificultad',v:2},{t:'Dificultad moderada',v:3},{t:'Mucha dificultad',v:4},{t:'Incapaz de dormir',v:5}] }
      ]}]
    }
  ]

};
