// ── APP ──────────────────────────────────────────────────────────────────────
const App = (() => {

  let pacs = [];
  let curPac = null;
  let curTab = null;
  let curScore = null;
  let _lastResult = null;

  // ── Storage ────────────────────────────────────────────────────────────────
  function load() {
    try { pacs = JSON.parse(localStorage.getItem('ha_ortho_v2') || '[]'); } catch(e) { pacs = []; }
  }
  function save() {
    try { localStorage.setItem('ha_ortho_v2', JSON.stringify(pacs)); } catch(e) {}
  }

  // ── Navigation ─────────────────────────────────────────────────────────────
  function go(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    window.scrollTo(0, 0);
    if (id === 's-home') renderList();
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  function edad(fn) {
    if (!fn) return '';
    const b = new Date(fn), n = new Date();
    let a = n.getFullYear() - b.getFullYear();
    if (n.getMonth() < b.getMonth() || (n.getMonth() === b.getMonth() && n.getDate() < b.getDate())) a--;
    return a + ' años';
  }

  function rl(r) {
    return { tobillo:'Tobillo/Pie', rodilla:'Rodilla', cadera:'Cadera', hombro:'Hombro', femur:'Fémur', humero:'Húmero/Codo' }[r] || r;
  }

  function initials(nombre) {
    return nombre.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  }

  function interpClass(interp) {
    if (['Excelente','Buena función','Mínima discapacidad'].includes(interp)) return 'interp-excelente';
    if (['Bueno','Función moderada','Discapacidad leve'].includes(interp)) return 'interp-bueno';
    if (['Regular','Moderado','Función limitada','Discapacidad moderada'].includes(interp)) return 'interp-regular';
    return 'interp-malo';
  }

  // ── Home ───────────────────────────────────────────────────────────────────
  function renderList() {
    const q = (document.getElementById('search')?.value || '').toLowerCase();
    const el = document.getElementById('patient-list');
    const filtered = pacs.filter(p =>
      p.nombre.toLowerCase().includes(q) ||
      (p.cirugia || '').toLowerCase().includes(q) ||
      (p.medico || '').toLowerCase().includes(q)
    );

    if (!filtered.length) {
      el.innerHTML = `<div class="empty-state">
        <div class="empty-icon">🦴</div>
        ${pacs.length === 0
          ? 'Ningún paciente registrado.<br>Tocá <b>+ Paciente</b> para comenzar.'
          : 'Sin resultados para esa búsqueda.'}
      </div>`;
      return;
    }

    el.innerHTML = filtered.map(p => {
      const ri = pacs.indexOf(p);
      const chips = (p.scores || []).slice(-3).map(s =>
        `<span class="chip">${s.nombre.split(' ')[0]} <b>${s.valor}</b></span>`
      ).join('');
      const meta = [p.fnac ? edad(p.fnac) : null, p.cirugia || null].filter(Boolean).join(' · ');
      return `<div class="patient-card" onclick="App.verPac(${ri})">
        <div class="card-top">
          <div>
            <p class="card-name">${p.nombre}</p>
            ${meta ? `<p class="card-meta">${meta}</p>` : ''}
          </div>
          <span class="region-pill">${rl(p.region)}</span>
        </div>
        ${chips ? `<div class="score-chips">${chips}</div>` : ''}
      </div>`;
    }).join('');
  }

  // ── Crear Paciente ─────────────────────────────────────────────────────────
  function crearPaciente() {
    const n = document.getElementById('f-nombre').value.trim();
    const r = document.getElementById('f-region').value;
    const err = document.getElementById('f-err');

    if (!n) { showErr(err, 'El nombre del paciente es obligatorio.'); return; }
    if (!r) { showErr(err, 'Seleccioná una región anatómica.'); return; }
    err.style.display = 'none';

    const p = {
      nombre: n,
      fnac: document.getElementById('f-fnac').value,
      region: r,
      cirugia: document.getElementById('f-cirugia').value.trim(),
      fcirugia: document.getElementById('f-fcirugia').value,
      control: document.getElementById('f-control').value,
      medico: document.getElementById('f-medico').value.trim(),
      creado: new Date().toISOString(),
      scores: []
    };

    pacs.push(p);
    save();

    // Reset form
    ['f-nombre','f-fnac','f-cirugia','f-fcirugia','f-medico'].forEach(id => {
      document.getElementById(id).value = '';
    });
    document.getElementById('f-region').value = '';
    document.getElementById('f-control').value = '3 meses';

    curPac = pacs.length - 1;
    curTab = null;
    verPac(curPac);
  }

  function showErr(el, msg) {
    el.textContent = msg;
    el.style.display = 'block';
  }

  // ── Ver Paciente ───────────────────────────────────────────────────────────
  function verPac(idx) {
    curPac = idx;
    const p = pacs[idx];
    const slist = SCORES[p.region] || [];
    if (!curTab || !slist.find(s => s.id === curTab)) curTab = slist[0]?.id || null;

    document.getElementById('p-titulo').textContent = p.nombre.split(' ')[0];
    document.getElementById('p-avatar').textContent = initials(p.nombre);
    document.getElementById('p-nombre').textContent = p.nombre;

    const metaParts = [];
    if (p.fnac) metaParts.push(edad(p.fnac));
    if (p.fcirugia) metaParts.push('Cx: ' + formatDate(p.fcirugia));
    document.getElementById('p-meta').textContent = metaParts.join(' · ') || ' ';
    document.getElementById('p-badge').textContent = rl(p.region);
    document.getElementById('p-cirugia').textContent = p.cirugia || '—';
    document.getElementById('p-control').textContent = p.control || '—';

    const medicRow = document.getElementById('p-medico-row');
    if (p.medico) {
      document.getElementById('p-medico').textContent = p.medico;
      medicRow.style.display = 'flex';
    } else {
      medicRow.style.display = 'none';
    }

    // Tabs
    document.getElementById('p-tabs').innerHTML = slist.map(s =>
      `<button class="tab${s.id === curTab ? ' active' : ''}" onclick="App.selTab('${s.id}')">${s.nombre.split(' ').slice(0, 2).join(' ')}</button>`
    ).join('');

    // Btn
    const btnWrap = document.querySelector('#s-paciente .btn-primary');
    if (btnWrap) btnWrap.className = 'btn-primary in-pac';

    renderHistorial(p);
    go('s-paciente');
  }

  function formatDate(d) {
    if (!d) return '';
    const parts = d.split('-');
    if (parts.length !== 3) return d;
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }

  function selTab(id) {
    curTab = id;
    const p = pacs[curPac];
    const slist = SCORES[p.region] || [];
    document.getElementById('p-tabs').innerHTML = slist.map(s =>
      `<button class="tab${s.id === id ? ' active' : ''}" onclick="App.selTab('${s.id}')">${s.nombre.split(' ').slice(0, 2).join(' ')}</button>`
    ).join('');
  }

  function eliminarPaciente() {
    const p = pacs[curPac];
    if (!confirm(`¿Eliminar a ${p.nombre}? Esta acción no se puede deshacer.`)) return;
    pacs.splice(curPac, 1);
    save();
    curPac = null;
    go('s-home');
  }

  function renderHistorial(p) {
    const el = document.getElementById('p-historial');
    const scores = p.scores || [];
    if (!scores.length) { el.innerHTML = ''; return; }
    let h = '<div class="section-label" style="padding:0;">Historial de scores</div><div class="historial-wrap" style="padding:0 0 40px;">';
    scores.slice().reverse().forEach(s => {
      h += `<div class="hist-row">
        <div>
          <p class="hist-name">${s.nombre}</p>
          <p class="hist-meta">${s.control} · ${new Date(s.fecha).toLocaleDateString('es-AR')}</p>
        </div>
        <div class="hist-score">
          <p class="hist-num">${s.valor}</p>
          <p class="hist-interp">${s.interp}</p>
        </div>
      </div>`;
    });
    h += '</div>';
    el.innerHTML = h;
  }

  // ── Score ──────────────────────────────────────────────────────────────────
  function irAScore() {
    const p = pacs[curPac];
    const slist = SCORES[p.region] || [];
    const sc = slist.find(s => s.id === curTab) || slist[0];
    if (!sc) return;
    curScore = sc.id;
    document.getElementById('score-titulo').textContent = sc.nombre;
    buildForm(sc, p);
    document.getElementById('score-result').style.display = 'none';
    document.getElementById('score-form').style.display = 'block';
    go('s-score');
  }

  function buildForm(sc, p) {
    let h = `<div class="score-context">
      <strong>${p.nombre}</strong>
      <span> · ${p.cirugia || rl(p.region)} · Control ${p.control}</span>
    </div>`;

    sc.secciones.forEach(sec => {
      h += `<p class="score-section-label">${sec.t}</p>`;
      sec.qs.forEach(q => {
        h += `<div class="score-q"><p class="q-label">${q.txt}</p>`;
        q.ops.forEach(o => {
          h += `<label class="opt"><input type="radio" name="${q.id}" value="${o.v}"> ${o.t}</label>`;
        });
        h += '</div>';
      });
    });

    h += `<button class="btn-primary" style="margin-top:12px;" onclick="App.calcScore()">Calcular score →</button>`;
    document.getElementById('score-form').innerHTML = h;
  }

  function getAllQ(sc) {
    const qs = [];
    sc.secciones.forEach(s => s.qs.forEach(q => qs.push(q.id)));
    return qs;
  }

  function calcScore() {
    const p = pacs[curPac];
    const slist = SCORES[p.region] || [];
    const sc = slist.find(s => s.id === curScore);
    if (!sc) return;

    const qs = getAllQ(sc);
    let total = 0, allOk = true;

    for (const qid of qs) {
      const sel = document.querySelector(`input[name="${qid}"]:checked`);
      if (!sel) { allOk = false; break; }
      total += parseInt(sel.value);
    }

    if (!allOk) {
      alert('Por favor completá todas las preguntas antes de calcular.');
      return;
    }

    // Normalizations
    let display = total;
    if (sc.id === 'fadi') display = Math.round(total / sc.max * 100);
    if (sc.id === 'qdash') display = Math.round(((total / qs.length) - 1) / 4 * 100);
    if (sc.id === 'sf12') display = Math.min(100, Math.round(total / 68 * 100));
    if (sc.id === 'koos') display = Math.round(total / (qs.length * 4) * 100);

    const interp = sc.interp(display);
    const cls = interpClass(interp);

    document.getElementById('r-scorename').textContent = sc.nombre;
    document.getElementById('r-num').textContent = display;
    document.getElementById('r-scale').textContent = sc.id === 'fadi' ? 'Índice 0–100' : 'de ' + sc.max + ' puntos';
    const ri = document.getElementById('r-interp');
    ri.textContent = interp;
    ri.className = 'result-interp ' + cls;
    document.getElementById('r-fecha').textContent =
      'Calculado el ' + new Date().toLocaleDateString('es-AR') + ' · Control ' + p.control;

    document.getElementById('score-form').style.display = 'none';
    document.getElementById('score-result').style.display = 'block';
    window.scrollTo(0, 0);

    _lastResult = {
      scoreId: sc.id,
      nombre: sc.nombre,
      valor: display,
      interp,
      fecha: new Date().toISOString(),
      control: p.control,
      medico: p.medico || ''
    };
  }

  function guardarScore() {
    if (!_lastResult) return;
    pacs[curPac].scores = pacs[curPac].scores || [];
    pacs[curPac].scores.push(_lastResult);
    save();
    _lastResult = null;
    alert('Score guardado correctamente.');
    verPac(curPac);
  }

  function rehacerScore() {
    document.getElementById('score-form').style.display = 'block';
    document.getElementById('score-result').style.display = 'none';
    window.scrollTo(0, 0);
  }

  // ── Init ───────────────────────────────────────────────────────────────────
  load();
  renderList();

  return {
    go, renderList, crearPaciente, verPac, selTab,
    eliminarPaciente, irAScore, calcScore, guardarScore,
    rehacerScore, get curPac() { return curPac; }
  };

})();
